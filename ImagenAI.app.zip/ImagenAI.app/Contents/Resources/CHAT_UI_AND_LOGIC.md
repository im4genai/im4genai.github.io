# Chat UI 现状交互与业务逻辑说明（用于后续 AppKit 重写对照）

> 本文记录 **当前 SwiftUI 版本** Chat 的 UI 交互行为与关键业务流程（截至本次代码状态）。后续用 AppKit 重写时，可按本文逐条对照实现与验收。

## 代码入口（你重写时最常对照的文件）

- **主界面容器**：`New/Features/Chat/Views/ChatView.swift`
- **消息列表（当前 SwiftUI 版本）**：`New/Features/Chat/Views/ChatMessageListView.swift`
- **旧的倒置列表（已废弃）**：`New/Features/Chat/Views/ChatScrollView.swift`（deprecated）
- **用户消息行**：`New/Features/Chat/Views/Rows/UserMessageRow.swift`
- **AI 消息行（含 loading/图片/按钮）**：`New/Features/Chat/Views/Rows/AIMessageRow.swift`
- **输入区**：`New/Features/Chat/Components/ChatInputArea.swift`
- **多行输入桥接（NSTextView）**：`New/Core/UIFoundation/AdaptiveTextView.swift`
- **业务 ViewModel（发送、loading、生成、落盘、状态队列）**：`New/Features/Chat/ViewModels/ChatViewModel.swift`
- **数据模型（会话/消息字段）**：`New/Core/Models/Models.swift`（`CreativeChatSession`、`CreativeChatMessageModel`）
- **图片 Review/标注模式**：`New/Features/Chat/Views/ImageReviewView.swift`

## 数据模型（消息/会话）

### `CreativeChatSession`
- `messages: [CreativeChatMessageModel]`
- `title`：首条用户消息会触发自动命名（取前 30 字符）
- `draftInput` / `draftImagesData`：草稿持久化（输入与已选图）
- `modelProviderRaw`：当前模型 provider
- `lastModified`：发送/生成后更新

### `CreativeChatMessageModel`（关键字段）
- `id: UUID`
- `role`（通过 `roleRaw` 映射）：`user` / `assistant`
- `content: String`
- `imagePath: String?`：生成图片文件路径（assistant）
- `imagesData: [Data]?`：用户上传的图片数据（user）
- `timestamp: Date`
- `statusText: String?`：用于 loading/思考过程/总结展示（assistant）
- `intentRaw: String?`：意图（由 brain 分析）
- `isLoading: Bool`：**loading 占位消息标记**
- `referenceImageIDs: [String]?`：本次生成引用的图片 ID 列表

## UI 结构与主要交互

### 主界面布局：`ChatView`

- **空态**：当 `session.messages.isEmpty && !isGenerating` 显示欢迎页（图标+文案）。
- **有消息**：显示消息列表 + 输入区。
- **Overlay**：
  - Toast（复制文案/复制图片成功提示）
  - Settings 弹层
  - ImageReviewView（标注/编辑模式）

### 输入区：`ChatInputArea`

#### 文本输入
- 使用 `AdaptiveTextView`（`NSTextView` bridge）实现多行输入与动态高度。
- Enter 发送、Shift+Enter 换行（由 `CommandTextView.doCommand` 控制）。
- `inputHeight` 在 `AdaptiveTextView.updateNSView` 根据排版高度计算并回写到 SwiftUI。

#### 图片输入（用户上传）
支持 3 种来源：
- **拖拽**（`onDrop` 支持 `.image` / `.fileURL`）
- **文件选择**（`fileImporter`）
- **粘贴**（`onPasteCommand`）

展示与交互：
- 预览区最多保留 3 张（超出会 `removeFirst()`）。
- 点击预览缩略图会往输入框插入 `"[IMG N]"` mention（`insertImageMention`）。
- 点击预览右上角删除按钮移除对应图片。

#### 模板/Style（Prompt 模板）
- 有一个 TemplatePicker 弹层（当前右侧列表已移除，但按钮仍在输入区工具条）。
- 发送时如果选了模板，会把输入拼接成：
  - `"\(input)\nwith style \"\(template.name)\": \(template.content)"`

#### 发送按钮语义
- 未生成时：发送（箭头）。
- 生成中时：显示 stop 图标（目前按钮仍复用 disabled 条件与 onSend 逻辑，是否真正 stop 由业务侧决定）。

### 消息行：User / AI

#### `UserMessageRow`（用户消息）
- 右对齐显示。
- hover 时出现复制按钮（复制 `message.content`）。
- 如果 `message.imagesData` 非空，会先展示图片（单图高度 200，多图 100）。

#### `AIMessageRow`（AI 消息）
状态分三类：
- **Loading**（`message.isLoading == true`）：
  - 显示 `ProgressView` + `statusText`（默认 "Thinking..."）
  - 显示固定大小 skeleton placeholder（目前为 360x200 的占位卡）
- **Error**：
  - `content` 以 `"Error:"` 开头或包含 `"API Error"`，显示红色错误文本
- **正常**：
  - `content` 非空则显示文本（可选中文本 selection）
  - `imagePath` 非空则展示生成图片

操作按钮（仅在非 loading 时显示；错误态也会显示以便 regenerate）：
- Regenerate
- Edit（进入 Review）
- Show in Finder
- Reply（“Add to Attachment”，把该图片作为附件引用）
- Copy Image
- 点击生成图片会打开文件（当前用 `NSWorkspace` 打开）

## 业务流程（发送 -> loading -> 成功/失败落地）

### 草稿保存（Draft）
`ChatViewModel` 会：
- 对 `currentInput` 做 0.5s debounce 后写入 `session.draftInput`
- 对 `selectedImages` 的变化立即写入 `session.draftImagesData`
- 草稿保存不更新 `lastModified`（避免仅输入导致会话排序变化）

### 发送入口（用户发送 / regenerate / review 发送）
入口统一会调用 `ChatViewModel.sendMessage(...)`（可能带 `isHiddenImage` 场景）。

流程（简化版）：
1. 校验：文本去空白后非空 或 有图片才允许发送。
2. 创建 user message：
   - `imagesData` 根据 `isHiddenImage` 决定是否写入消息（Review 模式可能隐藏图片以保持 UI 干净）。
3. append 到 `session.messages`，更新 `session.title`（首条时）、`session.modelProviderRaw`、`lastModified`。
4. 清空输入：`currentInput = ""`、`selectedImages = []`，清空草稿字段并落盘。
5. 调用 `generateResponse(prompt:imagesData:)` 开始生成。

### 生成开始：插入 loading 占位（关键点）
`generateResponse` 会立即：
- `isGenerating = true`
- 调用 `updateStatus("正在分析您的请求...")`
- append 一个 assistant `loadingMsg`：
  - `content = ""`
  - `statusText = "正在分析您的请求..."`
  - `isLoading = true`
  - `loadingMessageId = loadingMsg.id`
- 落盘

> 这条 loading 消息随后会被“就地更新”为最终消息（成功或失败），不会新增一条最终消息。

### 生成成功（Message Finalization - Success）
生成成功后会在主线程：
- `isGenerating = false`，清空状态队列显示
- 找到 `loadingMessageId` 对应的那条消息并更新：
  - `content = analysisResult.refinedPrompt`
  - `imagePath = url.path`
  - `statusText = analysisResult.reasoning`
  - `intentRaw = analysisResult.intent.rawValue`
  - `isLoading = false`
  - `referenceImageIDs = refImageIDs`
  - 更新 `session.lastModified`
- `loadingMessageId = nil`
- 落盘

### 生成失败（Message Finalization - Failure）
失败后会：
- `isGenerating = false`，清空状态队列显示
- `errorMessage = error.localizedDescription`
- 找到 loading 消息并更新：
  - `content = "Error: \(error.localizedDescription)"`
  - `isLoading = false`
- `loadingMessageId = nil`
- 落盘

### 状态文案队列（loadingStatusText）
`ChatViewModel` 有一个状态队列机制：
- `updateStatus(text)` 会把 text 入队
- 后台 Task 逐条显示，每条非空状态至少显示 1.2s
- `forceClearStatus()` 会清空队列并立即隐藏

## 当前“滚动/贴底”行为（SwiftUI 实现现状，仅供对照）

> 你计划用 AppKit 重写，下面这段只用于理解“目前产品表现”与“触发点”，方便你做等价替换。

### 滚动目标
当前版本使用 `ChatMessageListView`：
- `ScrollViewReader + LazyVStack`
- 列表尾部放置稳定底部锚点 `CHAT_BOTTOM_ANCHOR`
- 通过 `bottomInset`（来自输入区高度）为底部预留空间，避免最后一条被输入区遮挡

### 自动滚动触发点（和业务流对齐）
- 初次进入：无动画多次尝试 `scrollTo(bottomAnchor)`（避免可见滚动）
- 插入 loading：检测到 `messages.count` 增长且 `last.isLoading == true` 时滚到底
- loading 结束：检测 `last.isLoading true -> false` 先滚一次，再基于 contentHeight 变化/延迟兜底滚一次
- 用户手动离底：通过 pinned 判定认为用户离开底部后停止强制跟随

### Debug 日志
`ChatMessageListView` 在 DEBUG 下会打印前缀：
- `[ChatAutoScroll] ...`

## AppKit 重写建议的对照点（你后续实现时可按此拆模块）

- **消息数据源层**：按 `CreativeChatSession.messages` 的增量更新（插入、就地更新 loading->final）。
- **列表控件**：建议用 `NSScrollView + NSTableView` 或 `NSCollectionView`，关键是支持：
  - 追加行（user + loading）
  - “就地更新”行高度（loading->final，高度变化非常大）
  - pinned/near-bottom 判断（阈值）
  - 用户滚动时暂停自动滚动
- **输入区**：当前已是 `NSTextView`（可复用），需要同步高度变化与底部 inset。
- **图片解码/缓存**：避免在滚动/输入重绘时反复从磁盘解码导致闪烁；建议在 AppKit 重写时做集中缓存（按 path）。


